package co.com.utest.model;

public class Datos_Personales_Utest {

    private String strName;
    private String strLastName;
    private String strEmail;
    private String strMonthBirth;
    private String strBirthDay;
    private String strYearBirth;
    private String strCity;
    private String strZipPostalCode;
    private String strCountry;
    private String strPc;
    private String strVersion;
    private String strLanguage;
    private String strMobileDevice;
    private String strModel;
    private String strSO;
    private String strPassword;

    public String getStrPassword() {
        return strPassword;
    }

    public void setStrPassword(String strPassword) {
        this.strPassword = strPassword;
    }

    public Datos_Personales_Utest() {
    }


    public String getStrSO() {
        return strSO;
    }

    public void setStrSO(String strSO) {
        this.strSO = strSO;
    }


    public String getStrPc() {
        return strPc;
    }

    public void setStrPc(String strPc) {
        this.strPc = strPc;
    }

    public String getStrVersion() {
        return strVersion;
    }

    public void setStrVersion(String strVersion) {
        this.strVersion = strVersion;
    }

    public String getStrLanguage() {
        return strLanguage;
    }

    public void setStrLanguage(String strLanguage) {
        this.strLanguage = strLanguage;
    }

    public String getStrMobileDevice() {
        return strMobileDevice;
    }

    public void setStrMobileDevice(String strMobileDevice) {
        this.strMobileDevice = strMobileDevice;
    }

    public String getStrModel() {
        return strModel;
    }

    public void setStrModel(String strModel) {
        this.strModel = strModel;
    }

    public String getStrOperatingSystem() {
        return strOperatingSystem;
    }

    public void setStrOperatingSystem(String strOperatingSystem) {
        this.strOperatingSystem = strOperatingSystem;
    }

    private String strOperatingSystem;

    public String getStrName() {
        return strName;
    }

    public void setStrName(String strName) {
        this.strName = strName;
    }

    public String getStrLastName() {
        return strLastName;
    }

    public void setStrLastName(String strLastName) {
        this.strLastName = strLastName;
    }

    public String getStrEmail() {
        return strEmail;
    }

    public void setStrEmail(String strEmail) {
        this.strEmail = strEmail;
    }

    public String getStrMonthBirth() {
        return strMonthBirth;
    }

    public void setStrMonthBirth(String strMonthBirth) {
        this.strMonthBirth = strMonthBirth;
    }

    public String getStrBirthDay() {
        return strBirthDay;
    }

    public void setStrBirthDay(String strBirthDay) {
        this.strBirthDay = strBirthDay;
    }

    public String getStrYearBirth() {
        return strYearBirth;
    }

    public void setStrYearBirth(String strYearBirth) {
        this.strYearBirth = strYearBirth;
    }

    public String getStrCity() {
        return strCity;
    }

    public void setStrCity(String strCity) {
        this.strCity = strCity;
    }

    public String getStrZipPostalCode() {
        return strZipPostalCode;
    }

    public void setStrZipPostalCode(String strZipPostalCode) {
        this.strZipPostalCode = strZipPostalCode;
    }

    public String getStrCountry() {
        return strCountry;
    }

    public void setStrCountry(String strCountry) {
        this.strCountry = strCountry;
    }
}
